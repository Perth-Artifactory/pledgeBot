# frozen_string_literal: true

class SlackProgressBar
  VERSION = Gem::Version.new("0.1.0")
end
